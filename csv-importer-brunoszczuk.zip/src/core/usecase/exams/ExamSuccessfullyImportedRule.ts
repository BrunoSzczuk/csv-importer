import {ImportExamCommand} from "./ImportExamCommands";

export interface ExamSuccessfullyImportedRule extends ValidationRule<ImportExamCommand> {

}