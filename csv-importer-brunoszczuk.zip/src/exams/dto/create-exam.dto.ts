export class CreateExamDto {
}
